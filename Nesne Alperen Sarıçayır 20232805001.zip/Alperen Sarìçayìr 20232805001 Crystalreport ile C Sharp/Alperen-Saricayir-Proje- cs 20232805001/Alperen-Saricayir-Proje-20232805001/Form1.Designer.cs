﻿namespace Alperen_Saricayir_Proje_20232805001
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblKullaniciAdi = new System.Windows.Forms.Label();
            this.lblSifre = new System.Windows.Forms.Label();
            this.txtKullaniciAdi = new System.Windows.Forms.TextBox();
            this.txtSifre = new System.Windows.Forms.TextBox();
            this.btnGiris = new System.Windows.Forms.Button();
            this.pbOgrenciResmi = new System.Windows.Forms.PictureBox();
            this.pbKareKod = new System.Windows.Forms.PictureBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.lblHosGeldiniz = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbOgrenciResmi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKareKod)).BeginInit();
            this.SuspendLayout();
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblKullaniciAdi.Location = new System.Drawing.Point(316, 284);
            this.lblKullaniciAdi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            this.lblKullaniciAdi.Size = new System.Drawing.Size(159, 29);
            this.lblKullaniciAdi.TabIndex = 0;
            this.lblKullaniciAdi.Text = "Kullanıcı Adı";
            this.lblKullaniciAdi.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // lblSifre
            // 
            this.lblSifre.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblSifre.Location = new System.Drawing.Point(406, 326);
            this.lblSifre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSifre.Name = "lblSifre";
            this.lblSifre.Size = new System.Drawing.Size(70, 29);
            this.lblSifre.TabIndex = 1;
            this.lblSifre.Text = "Şifre";
            this.lblSifre.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtKullaniciAdi
            // 
            this.txtKullaniciAdi.Location = new System.Drawing.Point(478, 280);
            this.txtKullaniciAdi.Margin = new System.Windows.Forms.Padding(4);
            this.txtKullaniciAdi.Name = "txtKullaniciAdi";
            this.txtKullaniciAdi.Size = new System.Drawing.Size(330, 35);
            this.txtKullaniciAdi.TabIndex = 2;
            // 
            // txtSifre
            // 
            this.txtSifre.Location = new System.Drawing.Point(478, 326);
            this.txtSifre.Margin = new System.Windows.Forms.Padding(4);
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.Size = new System.Drawing.Size(330, 35);
            this.txtSifre.TabIndex = 3;
            // 
            // btnGiris
            // 
            this.btnGiris.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnGiris.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnGiris.Location = new System.Drawing.Point(621, 370);
            this.btnGiris.Margin = new System.Windows.Forms.Padding(4);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(188, 84);
            this.btnGiris.TabIndex = 4;
            this.btnGiris.Text = "GİRİŞ";
            this.btnGiris.UseVisualStyleBackColor = false;
            this.btnGiris.Click += new System.EventHandler(this.btnGiris_Click);
            // 
            // pbOgrenciResmi
            // 
            this.pbOgrenciResmi.Location = new System.Drawing.Point(0, 0);
            this.pbOgrenciResmi.Margin = new System.Windows.Forms.Padding(4);
            this.pbOgrenciResmi.Name = "pbOgrenciResmi";
            this.pbOgrenciResmi.Size = new System.Drawing.Size(210, 642);
            this.pbOgrenciResmi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbOgrenciResmi.TabIndex = 5;
            this.pbOgrenciResmi.TabStop = false;
            // 
            // pbKareKod
            // 
            this.pbKareKod.Location = new System.Drawing.Point(938, 0);
            this.pbKareKod.Margin = new System.Windows.Forms.Padding(4);
            this.pbKareKod.Name = "pbKareKod";
            this.pbKareKod.Size = new System.Drawing.Size(288, 642);
            this.pbKareKod.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbKareKod.TabIndex = 6;
            this.pbKareKod.TabStop = false;
            this.pbKareKod.Click += new System.EventHandler(this.pbKareKod_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.checkBox1.Location = new System.Drawing.Point(478, 241);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(198, 33);
            this.checkBox1.TabIndex = 12;
            this.checkBox1.Text = "Şifreyi Göster";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // lblHosGeldiniz
            // 
            this.lblHosGeldiniz.AutoSize = true;
            this.lblHosGeldiniz.Font = new System.Drawing.Font("Microsoft Sans Serif", 26F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblHosGeldiniz.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblHosGeldiniz.Location = new System.Drawing.Point(388, 141);
            this.lblHosGeldiniz.Name = "lblHosGeldiniz";
            this.lblHosGeldiniz.Size = new System.Drawing.Size(419, 59);
            this.lblHosGeldiniz.TabIndex = 13;
            this.lblHosGeldiniz.Text = "HOŞ GELDİNİZ.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1226, 642);
            this.Controls.Add(this.lblHosGeldiniz);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.pbKareKod);
            this.Controls.Add(this.pbOgrenciResmi);
            this.Controls.Add(this.btnGiris);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.txtKullaniciAdi);
            this.Controls.Add(this.lblSifre);
            this.Controls.Add(this.lblKullaniciAdi);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "5";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbOgrenciResmi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbKareKod)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblKullaniciAdi;
        private System.Windows.Forms.Label lblSifre;
        private System.Windows.Forms.TextBox txtKullaniciAdi;
        private System.Windows.Forms.TextBox txtSifre;
        private System.Windows.Forms.Button btnGiris;
        private System.Windows.Forms.PictureBox pbOgrenciResmi;
        private System.Windows.Forms.PictureBox pbKareKod;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label lblHosGeldiniz;
    }
}

