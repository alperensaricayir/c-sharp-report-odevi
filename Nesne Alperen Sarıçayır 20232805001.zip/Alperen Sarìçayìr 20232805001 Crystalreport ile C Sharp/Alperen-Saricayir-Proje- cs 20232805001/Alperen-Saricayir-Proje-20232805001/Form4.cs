﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Alperen_Saricayir_Proje_20232805001
{
    public partial class Form4 : Form
    {
        public string refNo { get; set; } // Form2'den gelecek RefNo

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // Eğer refNo boşsa uyar ve kapat
            if (string.IsNullOrEmpty(refNo))
            {
                MessageBox.Show("RefNo alınamadı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
                return;
            }

            // Veriyi çek ve CrystalReport'e bağla
            RaporHazirla(refNo);
        }

        private void RaporHazirla(string refNo)
        {
            try
            {
                // DataTable oluştur ve verileri doldur
                DataTable dt = new DataTable("Musteriler");
                dt.Columns.Add("RefNo", typeof(string));
                dt.Columns.Add("MusteriAdi", typeof(string));
                dt.Columns.Add("MusteriSoyadi", typeof(string));
                dt.Columns.Add("Gelir", typeof(decimal));
                dt.Columns.Add("Gider", typeof(decimal));
                dt.Columns.Add("Memleket", typeof(string));

                // Örnek veri ekleme (Veritabanından çektiğiniz verileri buraya eklemelisiniz)
                dt.Rows.Add(refNo, "ALİ", "VELİ", 5000, 1000, "ANKARA");
                // ... (Diğer veriler)

                // Crystal Report oluştur ve DataTable'ı bağla
                CrystalReport2 rapor = new CrystalReport2();
                rapor.SetDataSource(dt);
                crystalReportViewer1.ReportSource = rapor;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Rapor oluşturulurken hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}