﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using MessagingToolkit.QRCode.Codec;

namespace Alperen_Saricayir_Proje_20232805001
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            string kullaniciAdi = txtKullaniciAdi.Text.Trim();
            string sifre = txtSifre.Text.Trim();

            if (string.IsNullOrEmpty(kullaniciAdi))
            {
                MessageBox.Show("Kullanıcı adı boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(sifre))
            {
                MessageBox.Show("Şifre boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Kullanicilar.accdb;";
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM Kullanicilar WHERE KullaniciAdi = ? AND Sifre = ?";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@KullaniciAdi", kullaniciAdi);
                        cmd.Parameters.AddWithValue("@Sifre", sifre);
                        int count = (int)cmd.ExecuteScalar();

                        if (count > 0)
                        {
                            MessageBox.Show("Başarılı giriş!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Form2 form2 = new Form2();
                            form2.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Hatalı kullanıcı adı veya şifre!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtKullaniciAdi.Clear();
                            txtSifre.Clear();
                            txtKullaniciAdi.Focus();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanı bağlantı hatası: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

       
        private void ResimVeQRCodeGoster()
        {
            try
            {
                // 1️ Vesikalık Resmi Yükle
                string resimYolu = "alperen-vesikalik-saricayir-20232805001.png";
                Bitmap vesikalikResim = new Bitmap(Image.FromFile(resimYolu)); // Orijinal resmi kopyaladık

                // 2️ QR Kod Oluştur
                QRCodeEncoder qrKod = new QRCodeEncoder();
                qrKod.QRCodeScale = 6; // QR kod büyüklüğü
                Bitmap qrBitmap = qrKod.Encode("Alperen SARICAYIR - 20232805001");

                // 3️ QR Kodu Küçült (Çok büyükse resmi kaplamasın)
                int qrBoyut = vesikalikResim.Width / 3; // Resmin %33'ü kadar olacak
                Bitmap kucukQR = new Bitmap(qrBitmap, new Size(qrBoyut, qrBoyut));

                // 4️ Yeni Tuval (Bitmap) Oluştur (Resim + QR Kod İçin Yeterli Boşluk)
                int yeniGenislik = vesikalikResim.Width;
                int yeniYukseklik = vesikalikResim.Height + qrBoyut + 10; // QR kod için ekstra alan ekledik
                Bitmap yeniResim = new Bitmap(yeniGenislik, yeniYukseklik);

                // 5️ Yeni Bitmap Üzerine Çizim Yap (Önce Vesikalık Resim, Sonra QR Kod)
                using (Graphics g = Graphics.FromImage(yeniResim))
                {
                    
                    g.DrawImage(vesikalikResim, 0, 0); // Vesikalık resmi en üste çiz
                    g.DrawImage(kucukQR, (yeniGenislik - qrBoyut) / 2, vesikalikResim.Height + 5); // QR kodu ortala ve alta ekle
                }

                // 6️ PictureBox'a Yeni Resmi Yükle
                pbOgrenciResmi.Image = yeniResim;
                pbOgrenciResmi.SizeMode = PictureBoxSizeMode.AutoSize;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            ResimVeQRCodeGoster();
            if (checkBox1.Checked)
            {
                txtSifre.PasswordChar = '\0'; // Şifreyi göster
            }
            else
            {
                txtSifre.PasswordChar = '*'; // Şifreyi gizle
            }
        }

       

        

       

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtSifre.PasswordChar = '\0'; // Şifreyi göster
            }
            else
            {
                txtSifre.PasswordChar = '*'; // Şifreyi gizle
            }
        }

        private void pbKareKod_Click(object sender, EventArgs e)
        {

        }
    }
}
