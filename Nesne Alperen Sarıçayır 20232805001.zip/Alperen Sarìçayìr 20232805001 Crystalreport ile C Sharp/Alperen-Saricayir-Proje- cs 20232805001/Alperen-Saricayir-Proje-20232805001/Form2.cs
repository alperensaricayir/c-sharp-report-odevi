﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Alperen_Saricayir_Proje_20232805001
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        // Rastgele 3 karakterle RefNo oluşturma fonksiyonu
        private string GenerateRefNo(string musteriAdi)
        {
            Random rand = new Random();
            string yil = DateTime.Now.Year.ToString();
            string ilkHarf = musteriAdi.Substring(0, 1).ToUpper(); // Adın ilk harfi

            // Adın harflerinden rastgele 3 harf seçimi
            string randomString = "";
            for (int i = 0; i < 3; i++)
            {
                int index = rand.Next(0, musteriAdi.Length);
                randomString += musteriAdi[index].ToString().ToUpper(); // Karakterler büyük olacak
            }

            // Final RefNo: Örnek M2025ATA
            return string.Format("{0}{1}{2}", ilkHarf, yil, randomString);
        }

        // Veritabanında Referans Numarası var mı kontrolü
        private bool RefNoVarMi(string refNo)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;";
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM Musteriler WHERE RefNo = ?";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", refNo);
                        int count = (int)cmd.ExecuteScalar();
                        return count > 0;
                    }
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
        private void LoadData()
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;";
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM Musteriler";
                    OleDbDataAdapter adapter = new OleDbDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veri yükleme hatası: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        //private bool RefNoVarMi(string refNo)
        //{
        //    string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;";
        //    using (OleDbConnection conn = new OleDbConnection(connectionString))
        //    {
        //        try
        //        {
        //            conn.Open();
        //            string query = "SELECT COUNT(*) FROM Musteriler WHERE RefNo = ?";
        //            using (OleDbCommand cmd = new OleDbCommand(query, conn))
        //            {
        //                cmd.Parameters.AddWithValue("@RefNo", refNo);
        //                int count = (int)cmd.ExecuteScalar();
        //                return count > 0;
        //            }
        //        }
        //        catch (Exception)
        //        {
        //            return false;
        //        }
        //    }
        //}

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            string musteriAdi = txtMusteriAdi.Text.Trim();
            string musteriSoyadi = txtMusteriSoyadi.Text.Trim();
            string gelir = txtGelir.Text.Trim();
            string gider = txtGider.Text.Trim();
            string memleket = comboMemleket.SelectedItem != null ? comboMemleket.SelectedItem.ToString() : string.Empty;

            // Alanlar boş mu kontrol et
            if (string.IsNullOrEmpty(musteriAdi) || string.IsNullOrEmpty(musteriSoyadi) ||
                string.IsNullOrEmpty(gelir) || string.IsNullOrEmpty(gider) || string.IsNullOrEmpty(memleket))
            {
                MessageBox.Show("Tüm alanlar doldurulmalıdır!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Referans numarasını oluştur
            string refNo = GenerateRefNo(musteriAdi);

            // Veritabanı kontrolü
            if (RefNoVarMi(refNo))
            {
                MessageBox.Show("Bu referans numarası zaten mevcut. Lütfen tekrar deneyin.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Kullanıcıya kaydetme onayı ver
            DialogResult dialogResult = MessageBox.Show(string.Format("{0} isimli kişiyi kaydetmek istiyor musunuz?", musteriAdi), "Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                // Veritabanına kaydet
                string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;";
                using (OleDbConnection conn = new OleDbConnection(connectionString))
                {
                    try
                    {
                        conn.Open();
                        string query = "INSERT INTO Musteriler (RefNo, [Müşteri Adı], [Müşteri Soyadı], Gelir, Gider, Memleket) VALUES (?, ?, ?, ?, ?, ?)";
                        using (OleDbCommand cmd = new OleDbCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("?", refNo);
                            cmd.Parameters.AddWithValue("?", musteriAdi);
                            cmd.Parameters.AddWithValue("?", musteriSoyadi);
                            cmd.Parameters.AddWithValue("?", gelir);
                            cmd.Parameters.AddWithValue("?", gider);
                            cmd.Parameters.AddWithValue("?", memleket);

                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("Müşteri başarıyla kaydedildi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Veritabanı hatası: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadData();
            // ComboBox için memleket verilerini yükle
            string[] memleketler = System.IO.File.ReadAllLines("memleketler.txt");
            comboMemleket.Items.AddRange(memleketler);
        }



        private void txtMusteriSoyadi_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Sadece büyük harf ve boşluk karakterine izin ver
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != ' ' && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Geçersiz karakteri engelle
            }

            // Küçük harflerin girişini engelle
            if (char.IsLower(e.KeyChar))
            {
                e.KeyChar = char.ToUpper(e.KeyChar); // Küçük harfi büyük harfe çevir
            }
        }

        private void txtGelir_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Sayı girilmesine izin ver
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8) // 8, backspace tuşu
            {
                e.Handled = true; // Geçersiz karakteri engelle
            }
        }

        private void txtGider_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Sayı girilmesine izin ver
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != 8) // 8, backspace tuşu
            {
                e.Handled = true; // Geçersiz karakteri engelle
            }
        }

        private void txtMusteriAdi_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != ' ' && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }

            if (char.IsLower(e.KeyChar))
            {
                e.KeyChar = char.ToUpper(e.KeyChar);
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            // Silme işlemi
            string refNo = Microsoft.VisualBasic.Interaction.InputBox("Silinecek kişinin RefNo'sunu girin:", "Kayıt Silme", "");
            if (string.IsNullOrEmpty(refNo))
            {
                MessageBox.Show("RefNo boş olamaz!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Veritabanında refNo'yu kontrol et
            if (!RefNoVarMi(refNo))
            {
                MessageBox.Show("Bu RefNo ile bir kayıt bulunamadı.", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Kaydı silme
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Musteriler.accdb;";
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM Musteriler WHERE RefNo = ?";
                    using (OleDbCommand cmd = new OleDbCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("?", refNo);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Kayıt başarıyla silindi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Veritabanı hatası: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            LoadData();
        }

        private void btnRaporla_Click(object sender, EventArgs e)
        {
            if (radioBtnArananKayit.Checked)
            {
                string refNo = Microsoft.VisualBasic.Interaction.InputBox("Raporlamak istediğiniz kaydın RefNo'sunu girin:", "Kayıt Raporlama", "");

                if (string.IsNullOrEmpty(refNo))
                {
                    MessageBox.Show("RefNo girilmedi!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (RefNoVarMi(refNo))
                {
                    Form4 form4 = new Form4();
                    form4.refNo = refNo;
                    form4.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Girilen RefNo'ya sahip kayıt bulunamadı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (radioBtnTumBilgiler.Checked)
            {
                Form3 form3 = new Form3();
                form3.ShowDialog();
            }
            else
            {
                MessageBox.Show("Lütfen bir seçim yapın!", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void radioBtnTumBilgiler_CheckedChanged(object sender, EventArgs e)
        {
            btnRaporla.Enabled = true;
        }

        private void radioBtnArananKayit_CheckedChanged(object sender, EventArgs e)
        {
            btnRaporla.Enabled = true;
        }
    }
}
