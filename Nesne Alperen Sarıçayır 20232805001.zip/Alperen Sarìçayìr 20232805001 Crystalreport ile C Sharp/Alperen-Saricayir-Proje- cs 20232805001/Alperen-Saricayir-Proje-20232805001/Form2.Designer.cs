﻿namespace Alperen_Saricayir_Proje_20232805001
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMusteriAdi = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtMusteriSoyadi = new System.Windows.Forms.TextBox();
            this.txtGelir = new System.Windows.Forms.TextBox();
            this.txtGider = new System.Windows.Forms.TextBox();
            this.comboMemleket = new System.Windows.Forms.ComboBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnRaporla = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.radioBtnTumBilgiler = new System.Windows.Forms.RadioButton();
            this.radioBtnArananKayit = new System.Windows.Forms.RadioButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtMusteriAdi
            // 
            this.txtMusteriAdi.Location = new System.Drawing.Point(161, 19);
            this.txtMusteriAdi.Name = "txtMusteriAdi";
            this.txtMusteriAdi.Size = new System.Drawing.Size(222, 35);
            this.txtMusteriAdi.TabIndex = 0;
            this.txtMusteriAdi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMusteriAdi_KeyPress_1);
            // 
            // label1
            // 
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(94, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "İsim";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // txtMusteriSoyadi
            // 
            this.txtMusteriSoyadi.Location = new System.Drawing.Point(161, 63);
            this.txtMusteriSoyadi.Name = "txtMusteriSoyadi";
            this.txtMusteriSoyadi.Size = new System.Drawing.Size(222, 35);
            this.txtMusteriSoyadi.TabIndex = 2;
            this.txtMusteriSoyadi.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMusteriSoyadi_KeyPress);
            // 
            // txtGelir
            // 
            this.txtGelir.Location = new System.Drawing.Point(161, 104);
            this.txtGelir.Name = "txtGelir";
            this.txtGelir.Size = new System.Drawing.Size(222, 35);
            this.txtGelir.TabIndex = 3;
            this.txtGelir.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGelir_KeyPress);
            // 
            // txtGider
            // 
            this.txtGider.Location = new System.Drawing.Point(161, 145);
            this.txtGider.Name = "txtGider";
            this.txtGider.Size = new System.Drawing.Size(222, 35);
            this.txtGider.TabIndex = 4;
            this.txtGider.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGider_KeyPress);
            // 
            // comboMemleket
            // 
            this.comboMemleket.FormattingEnabled = true;
            this.comboMemleket.Location = new System.Drawing.Point(161, 186);
            this.comboMemleket.Name = "comboMemleket";
            this.comboMemleket.Size = new System.Drawing.Size(222, 37);
            this.comboMemleket.TabIndex = 5;
            // 
            // btnKaydet
            // 
            this.btnKaydet.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnKaydet.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnKaydet.Location = new System.Drawing.Point(400, 22);
            this.btnKaydet.Name = "btnKaydet";
            this.btnKaydet.Size = new System.Drawing.Size(174, 64);
            this.btnKaydet.TabIndex = 6;
            this.btnKaydet.Text = "KAYDET";
            this.btnKaydet.UseVisualStyleBackColor = false;
            this.btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnSil.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSil.Location = new System.Drawing.Point(400, 92);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(174, 64);
            this.btnSil.TabIndex = 7;
            this.btnSil.Text = "SİL";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnRaporla
            // 
            this.btnRaporla.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnRaporla.Enabled = false;
            this.btnRaporla.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRaporla.Location = new System.Drawing.Point(400, 162);
            this.btnRaporla.Name = "btnRaporla";
            this.btnRaporla.Size = new System.Drawing.Size(174, 64);
            this.btnRaporla.TabIndex = 8;
            this.btnRaporla.Text = "RAPORLA";
            this.btnRaporla.UseVisualStyleBackColor = false;
            this.btnRaporla.Click += new System.EventHandler(this.btnRaporla_Click);
            // 
            // label2
            // 
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(50, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 29);
            this.label2.TabIndex = 9;
            this.label2.Text = "Soyisim";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(85, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 29);
            this.label3.TabIndex = 10;
            this.label3.Text = "Gelir";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(77, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 29);
            this.label4.TabIndex = 11;
            this.label4.Text = "Gider";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label5
            // 
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(28, 189);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 29);
            this.label5.TabIndex = 12;
            this.label5.Text = "Memleket";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // radioBtnTumBilgiler
            // 
            this.radioBtnTumBilgiler.AutoSize = true;
            this.radioBtnTumBilgiler.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioBtnTumBilgiler.Location = new System.Drawing.Point(55, 236);
            this.radioBtnTumBilgiler.Name = "radioBtnTumBilgiler";
            this.radioBtnTumBilgiler.Size = new System.Drawing.Size(287, 33);
            this.radioBtnTumBilgiler.TabIndex = 13;
            this.radioBtnTumBilgiler.TabStop = true;
            this.radioBtnTumBilgiler.Text = "Tüm Bilgileri Raporla";
            this.radioBtnTumBilgiler.UseVisualStyleBackColor = true;
            this.radioBtnTumBilgiler.CheckedChanged += new System.EventHandler(this.radioBtnTumBilgiler_CheckedChanged);
            // 
            // radioBtnArananKayit
            // 
            this.radioBtnArananKayit.AutoSize = true;
            this.radioBtnArananKayit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.radioBtnArananKayit.Location = new System.Drawing.Point(55, 275);
            this.radioBtnArananKayit.Name = "radioBtnArananKayit";
            this.radioBtnArananKayit.Size = new System.Drawing.Size(232, 33);
            this.radioBtnArananKayit.TabIndex = 14;
            this.radioBtnArananKayit.TabStop = true;
            this.radioBtnArananKayit.Text = "Seçileni Raporla";
            this.radioBtnArananKayit.UseVisualStyleBackColor = true;
            this.radioBtnArananKayit.CheckedChanged += new System.EventHandler(this.radioBtnArananKayit_CheckedChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.Location = new System.Drawing.Point(0, 314);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(1389, 391);
            this.dataGridView1.TabIndex = 15;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1389, 705);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.radioBtnArananKayit);
            this.Controls.Add(this.radioBtnTumBilgiler);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnRaporla);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.btnKaydet);
            this.Controls.Add(this.comboMemleket);
            this.Controls.Add(this.txtGider);
            this.Controls.Add(this.txtGelir);
            this.Controls.Add(this.txtMusteriSoyadi);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMusteriAdi);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMusteriAdi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMusteriSoyadi;
        private System.Windows.Forms.TextBox txtGelir;
        private System.Windows.Forms.TextBox txtGider;
        private System.Windows.Forms.ComboBox comboMemleket;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.Button btnRaporla;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton radioBtnTumBilgiler;
        private System.Windows.Forms.RadioButton radioBtnArananKayit;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}