﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using Microsoft.VisualBasic;
using System.IO;
using Microsoft.Reporting.WinForms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsDigit(e.KeyChar);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsDigit(e.KeyChar);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsLetter(e.KeyChar);
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = Char.IsLetter(e.KeyChar);
        }

        void guncelle()
        {
            DataTable tablo = new DataTable();
            OleDbDataAdapter adaptor = new OleDbDataAdapter("Select * from veriler", Form1.baglan);
            adaptor.Fill(tablo);
            dataGridView1.DataSource = tablo;

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            comboBox1.Items.AddRange(File.ReadAllLines("memleket.txt"));
            guncelle();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Lütfen müşteri adını giriniz!","MÜŞTERİ ADI");
                return;
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("Lütfen müşteri soyadını giriniz!","MÜŞTERİ SOYADI");
                return;
            }
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Lütfen memleketi seçiniz!", "MEMLEKET");
                return;
            }
            if (textBox3.Text == "")
            {
                MessageBox.Show("Lütfen gelir giriniz!", "GELİR");
                return;
            }
            if (textBox4.Text == "")
            {
                MessageBox.Show("Lütfen gider giriniz!", "GİDER");
                return;
            }
            Form1.baglan.Close();
            string ilkharf = textBox1.Text.Substring(0, 1).ToUpper();
            string tarih = DateTime.Now.Year.ToString();
            int kalan = textBox1.Text.Length - 2;
            Random rastgele = new Random();
            string sifre = "";
            for (int i = 1; i <= kalan; i++)
            {
                int karakter = rastgele.Next(0, textBox1.Text.Trim().Length);
                sifre += textBox1.Text.Trim()[karakter];
            }

            string refno = ilkharf + tarih + sifre;
            OleDbCommand kontrol = new OleDbCommand("Select Count(*) From veriler Where REFNO=@R", Form1.baglan);
            kontrol.Parameters.Add(new OleDbParameter("@R", refno));
            Form1.baglan.Open();
            int say = Convert.ToInt32(kontrol.ExecuteScalar());
            Form1.baglan.Close();
            if (say > 0)
            {
                MessageBox.Show("OLUŞTURULAN REFERANS NUMARASI ZATEN MEVCUT YENİ BİR NUMARA OLUŞTURUNUZ...","MEVCUT");
                return;
            }

            DialogResult soru;

            soru = MessageBox.Show("KAYIT YAPILSIN MI?", "KAYIT", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (soru == System.Windows.Forms.DialogResult.Yes)
            {
                OleDbCommand kaydet = new OleDbCommand("insert into veriler(REFNO,ADI,SOYADI,MEMLEKET,GELIR,GIDER) values(@R,@A,@S,@M,@GE,@GI)", Form1.baglan);
                kaydet.Parameters.Add(new OleDbParameter("@R", refno));
                kaydet.Parameters.Add(new OleDbParameter("@A", textBox1.Text));
                kaydet.Parameters.Add(new OleDbParameter("@S", textBox2.Text));
                kaydet.Parameters.Add(new OleDbParameter("@M", comboBox1.SelectedItem));
                kaydet.Parameters.Add(new OleDbParameter("@GE", textBox3.Text));
                kaydet.Parameters.Add(new OleDbParameter("@GI", textBox4.Text));
                Form1.baglan.Open();
                kaydet.ExecuteNonQuery();
                Form1.baglan.Close();
                guncelle();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                comboBox1.SelectedIndex = -1;

            }
            else
            {
                MessageBox.Show("KAYIT YAPILMADI...","KAYIT BAŞARISIZ");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                comboBox1.SelectedIndex = -1;
            }
        }

        Int32 refno;
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string refno = Interaction.InputBox("Silinecek Olan Verinin Referans No'su?", "REFERANS-NO");
                if (string.IsNullOrEmpty(refno))
                {
                    MessageBox.Show("Lütfen Referans No'yu Giriniz...","REFNO GİRİNİZ");
                    return;
                }
                OleDbCommand kontrolref = new OleDbCommand("SELECT COUNT(*) FROM veriler WHERE REFNO = @R", Form1.baglan);
                kontrolref.Parameters.Add(new OleDbParameter("@R", refno));

                Form1.baglan.Open();
                int say = Convert.ToInt32(kontrolref.ExecuteScalar());
                Form1.baglan.Close();

                if (say == 0)
                {
                    MessageBox.Show("Bu referans numarası mevcut değil.","REFERANS NO HATASI");
                    return;
                }

                OleDbCommand sil = new OleDbCommand("delete from veriler where REFNO=@R", Form1.baglan);
                sil.Parameters.Add(new OleDbParameter("@R", refno));
                Form1.baglan.Open();
                sil.ExecuteNonQuery();
                Form1.baglan.Close();
                guncelle();
                MessageBox.Show("Veri başarıyla silindi.","BAŞARILI");
            }

            catch
            {
                MessageBox.Show("Lütfen geçerli bir Referans No giriniz...","REFERANS NO HATASI");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                Form3 form3 = new Form3();
                form3.ShowDialog();
                return;
                
            }
            if (radioButton2.Checked)
            {
                 string refNo = Interaction.InputBox("RefNo'yu girin:", "RefNo Sorgulama", "");
                 if (!string.IsNullOrEmpty(refNo))
                {
                    Form3 raporEkrani = new Form3(refNo);
                    raporEkrani.ShowDialog();
                }
            }
            else
            {
                MessageBox.Show("Lütfen hangi bilgilerin raporlanacağını seçiniz!","RAPOR HATASI");
                return;
            }
        }    
    }
}

