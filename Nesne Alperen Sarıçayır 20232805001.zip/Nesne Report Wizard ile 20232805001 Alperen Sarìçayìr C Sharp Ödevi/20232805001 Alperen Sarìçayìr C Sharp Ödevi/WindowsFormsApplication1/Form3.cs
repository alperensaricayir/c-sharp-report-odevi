﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using Microsoft.Reporting.WinForms;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        private string refNo;

        public Form3()
        {
            InitializeComponent();
            refNo = null;
        }

        public Form3(string gelenRefNo)
        {
            InitializeComponent();
            refNo = gelenRefNo;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            //// TODO: This line of code loads data into the 'bilgilerDataSet.veriler' table. You can move, or remove it, as needed.
            OleDbConnection bag = new OleDbConnection
        ("Provider=Microsoft.Ace.Oledb.12.0; Data Source=bilgiler.accdb");

        string sql;

        if (string.IsNullOrEmpty(refNo))
        {
            sql = "SELECT * FROM veriler";
        }
        else
        {
            sql = "SELECT * FROM veriler WHERE RefNo = ?";
        }

        OleDbDataAdapter adaptor = new OleDbDataAdapter(sql, bag);

        if (!string.IsNullOrEmpty(refNo))
        {
            adaptor.SelectCommand.Parameters.AddWithValue("?", refNo);
        }

        DataSet dataSet = new DataSet();
        adaptor.Fill(dataSet, "veriler");

        ReportDataSource rapor = new ReportDataSource("DataSet1", dataSet.Tables["veriler"]);
        reportViewer1.LocalReport.DataSources.Clear();
        reportViewer1.LocalReport.DataSources.Add(rapor);
        reportViewer1.RefreshReport();
        }
    }
}