﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static OleDbConnection baglan = new OleDbConnection("Provider=Microsoft.Ace.Oledb.12.0; Data Source=bilgiler.accdb");
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Lütfen kullanıcı adı giriniz!","KULLANICI ADI");
                return;
            }
            if (textBox2.Text == "")
            {
                MessageBox.Show("Lütfen şifre giriniz!","ŞİFRE");
                return;
            }
            OleDbCommand komut = new OleDbCommand("Select Count (*) From admin Where KULLANICI='" + textBox1.Text + "' and SIFRE='" + textBox2.Text + "'", baglan);
            baglan.Open();
            int sayi = Convert.ToInt32(komut.ExecuteScalar());
            if (sayi == 1)
            {
                MessageBox.Show("HOŞ GELDİNİZ!","GİRİŞ BAŞARILI");
                Form2 form2 = new Form2();
                this.Hide();
                form2.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("YANLIŞ KULLANICI ADI VEYA ŞİFRE","HATALI GİRİŞ");
                textBox1.Clear();
                textBox2.Clear();
                textBox1.Focus();
            }
            baglan.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
